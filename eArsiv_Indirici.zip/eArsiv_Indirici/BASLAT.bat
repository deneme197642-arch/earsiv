@echo off
cd /d "%~dp0"
title e-Arsiv Fatura Indirici

rem ---- Python var mi? ----
set "PY="
py -3 --version >nul 2>&1 && set "PY=py -3"
if not defined PY python --version >nul 2>&1 && set "PY=python"

if not defined PY (
    echo.
    echo Python bulunamadi, otomatik kuruluyor. Lutfen bekleyin...
    echo.
    winget install -e --id Python.Python.3.12 --accept-package-agreements --accept-source-agreements
    echo.
    echo ===============================================================
    echo  Python kuruldu. Bu pencereyi KAPATIN ve BASLAT.bat dosyasina
    echo  tekrar cift tiklayin.
    echo ===============================================================
    pause
    exit /b
)

rem ---- Ilk calistirmada gerekli paketleri kur ----
if not exist "kurulum_tamam.txt" (
    echo.
    echo Ilk kurulum yapiliyor, bu islem birkac dakika surebilir...
    echo.
    %PY% -m pip install --upgrade pip
    %PY% -m pip install -r requirements.txt
    if errorlevel 1 goto hata
    %PY% -m playwright install chromium
    if errorlevel 1 goto hata
    echo tamam> "kurulum_tamam.txt"
    echo.
    echo Kurulum tamamlandi.
)

rem ---- Programi baslat ----
echo Program aciliyor... (bu pencereyi kapatmayin)
%PY% earsiv_indir.py
if errorlevel 1 pause
exit /b

:hata
echo.
echo ===============================================================
echo  KURULUMDA HATA OLUSTU. Yukaridaki mesajin ekran goruntusunu
echo  alip gonderin.
echo ===============================================================
pause

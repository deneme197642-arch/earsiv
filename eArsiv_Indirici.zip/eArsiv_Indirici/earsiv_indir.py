# -*- coding: utf-8 -*-
"""
GİB e-Arşiv Fatura Toplu İndirici
---------------------------------
- Mükellef kodu / şifreleri mukellefler.xlsx dosyasından okur
- Arayüzden mükellef(ler) ve dönem(ler) seçilir
- Güvenlik (doğrulama) kodu açılan tarayıcıda elle girilir
- Her dönem 7'şer günlük parçalar halinde Excel olarak indirilir
- Parçalar tek bir Excel dosyasında birleştirilir (tekrarlar ayıklanır)

Kurulum:
    pip install -r requirements.txt
    playwright install chromium
Çalıştırma:
    python earsiv_indir.py
"""
import os
import re
import sys
import queue
import calendar
import threading
import time
import webbrowser
import traceback
import warnings
from datetime import date

import tkinter as tk
from tkinter import ttk, filedialog, messagebox

import pandas as pd
from openpyxl.styles import Font, PatternFill, Alignment
from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout

warnings.filterwarnings("ignore")

# ----------------------------------------------------------------- AYARLAR ---
GIB_URL = "https://dijital.gib.gov.tr/portal/login"
GUN_ARALIGI = 7                 # kaç günlük parçalar halinde indirilecek
CAPTCHA_BEKLEME_SN = 300        # güvenlik kodu için en fazla bekleme süresi
INDIRME_BEKLEME_SN = 60         # tek bir Excel indirmesi için bekleme süresi
DONEM_SAYISI = 3                # listede gösterilecek geçmiş ay sayısı
BU_AY_DAHIL = False             # True yapılırsa içinde bulunulan ay da listeye eklenir

AY_ADLARI = ["Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz",
             "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"]
AY_KISA = ["Oca", "Şub", "Mar", "Nis", "May", "Haz", "Tem", "Ağu", "Eyl",
           "Eki", "Kas", "Ara"]


# ------------------------------------------------------- YARDIMCI FONKSİYON ---
def uygulama_klasoru():
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


def temiz_ad(s):
    s = re.sub(r'[\\/:*?"<>|]+', "_", str(s)).strip()
    return s[:60] or "mukellef"


def donemleri_listele(adet=DONEM_SAYISI, bu_ay_dahil=BU_AY_DAHIL):
    """Bilgisayarın tarihine göre geriye dönük dönemler (en yeni en üstte).
    Örn. Kasım ayında: Ekim, Eylül, Ağustos. Her ay kendiliğinden kayar."""
    bugun = date.today()
    y, m = bugun.year, bugun.month
    donemler = [(y, m)] if bu_ay_dahil else []
    for _ in range(adet):
        m -= 1
        if m == 0:
            m, y = 12, y - 1
        donemler.append((y, m))
    return donemler


def haftalik_parcalar(yil, ay):
    """Ayı 7'şer günlük (bas, bit) parçalara böler. Gelecek günler atlanır."""
    bugun = date.today()
    son_gun = calendar.monthrange(yil, ay)[1]
    parcalar, bas = [], 1
    while bas <= son_gun:
        bit = min(bas + GUN_ARALIGI - 1, son_gun)
        d_bas, d_bit = date(yil, ay, bas), date(yil, ay, bit)
        if d_bas > bugun:
            break
        parcalar.append((d_bas, min(d_bit, bugun)))
        bas = bit + 1
    return parcalar


def mukellefleri_oku(yol):
    df = pd.read_excel(yol, dtype=str).fillna("")
    sutunlar = {str(c).strip().lower(): c for c in df.columns}

    def bul(*adaylar):
        for a in adaylar:
            for k, v in sutunlar.items():
                if a in k:
                    return v
        return None

    c_ad = bul("unvan", "ünvan", "ad")
    c_kod = bul("kullanıcı", "kullanici", "vkn", "tckn", "kod")
    c_sifre = bul("şifre", "sifre", "parola")
    if not c_kod or not c_sifre:
        raise ValueError("Excel'de 'Kullanıcı Kodu' ve 'Şifre' sütunları bulunamadı.")

    liste = []
    for _, r in df.iterrows():
        kod = re.sub(r"\.0$", "", str(r[c_kod]).strip())
        sifre = str(r[c_sifre]).strip()
        if not kod or not sifre:
            continue
        unvan = str(r[c_ad]).strip() if c_ad else ""
        liste.append({"unvan": unvan or kod, "kod": kod, "sifre": sifre})
    return liste


# ------------------------------------------------------ EXCEL BİRLEŞTİRME ---
BASLIK_ANAHTARLARI = ("ettn", "fatura no", "fatura numara", "belge no",
                      "alıcı", "vkn", "tckn")
SAYISAL_ANAHTARLAR = ("tutar", "toplam", "matrah", "kdv", "fiyat")


def tablo_oku(yol):
    """GİB'den inen dosyayı okur; başlık satırını kendisi bulur."""
    ext = os.path.splitext(yol)[1].lower()
    if ext in (".csv", ".txt"):
        ham = pd.read_csv(yol, header=None, dtype=str, sep=None, engine="python")
    else:
        ham = pd.read_excel(yol, header=None, dtype=str)
    if ham.empty:
        return pd.DataFrame()

    baslik_idx = 0
    for i in range(min(20, len(ham))):
        satir = " ".join(str(x) for x in ham.iloc[i].tolist() if pd.notna(x)).lower()
        if any(k in satir for k in BASLIK_ANAHTARLARI):
            baslik_idx = i
            break

    basliklar = []
    for j, c in enumerate(ham.iloc[baslik_idx].tolist()):
        ad = str(c).strip() if pd.notna(c) and str(c).strip() else f"Kolon{j + 1}"
        while ad in basliklar:
            ad += "_"
        basliklar.append(ad)

    df = ham.iloc[baslik_idx + 1:].copy()
    df.columns = basliklar
    return df.dropna(how="all")


def sayiya_cevir(s):
    dolu = s.notna().sum()
    if dolu == 0:
        return s
    x = pd.to_numeric(s, errors="coerce")
    if x.notna().sum() < dolu * 0.8:   # "1.234,56" gibi Türkçe biçim
        y = pd.to_numeric(s.astype(str).str.replace(".", "", regex=False)
                          .str.replace(",", ".", regex=False), errors="coerce")
        if y.notna().sum() > x.notna().sum():
            x = y
    return x if x.notna().sum() >= dolu * 0.8 else s


def tarihe_cevir(s):
    try:
        return pd.to_datetime(s, dayfirst=True, errors="coerce", format="mixed")
    except (TypeError, ValueError):
        return pd.to_datetime(s, dayfirst=True, errors="coerce")


def parcalari_birlestir(dosyalar, yil, ay, hedef_yol, log):
    tablolar = []
    for yol in dosyalar:
        try:
            df = tablo_oku(yol)
            if not df.empty:
                tablolar.append(df)
        except Exception as e:
            log(f"   ! {os.path.basename(yol)} okunamadı: {e}")
    if not tablolar:
        log("   Bu dönem için hiç fatura bulunamadı, birleşik dosya oluşturulmadı.")
        return 0

    tum = pd.concat(tablolar, ignore_index=True, sort=False)
    tum = tum.dropna(axis=1, how="all")
    kolonlar = [str(c) for c in tum.columns]

    # ETTN'si boş olan (toplam/alt bilgi) satırları at, tekrarları ayıkla
    ettn = next((c for c in tum.columns if "ettn" in str(c).lower()), None)
    if ettn:
        tum = tum[tum[ettn].notna() & (tum[ettn].astype(str).str.strip() != "")]
    once = len(tum)
    tum = tum.drop_duplicates(subset=[ettn] if ettn else None)
    if once - len(tum):
        log(f"   {once - len(tum)} tekrar eden satır çıkarıldı.")

    # Dönem dışına taşan faturaları çıkar
    tcol = (next((c for c in tum.columns if "fatura tarih" in str(c).lower()), None)
            or next((c for c in tum.columns if "tarih" in str(c).lower()), None))
    if tcol:
        t = tarihe_cevir(tum[tcol])
        maske = t.isna() | ((t.dt.year == yil) & (t.dt.month == ay))
        if (~maske).sum():
            log(f"   Dönem dışı {(~maske).sum()} satır çıkarıldı.")
        tum = tum[maske]
        t = tarihe_cevir(tum[tcol])
        tum = tum.assign(_sira=t).sort_values("_sira", kind="stable").drop(columns="_sira")

    for c in tum.columns:
        if any(k in str(c).lower() for k in SAYISAL_ANAHTARLAR):
            tum[c] = sayiya_cevir(tum[c])

    sayfa = "e-Arşiv Faturalar"
    with pd.ExcelWriter(hedef_yol, engine="openpyxl") as w:
        tum.to_excel(w, index=False, sheet_name=sayfa)
        ws = w.sheets[sayfa]
        baslik_font = Font(name="Arial", bold=True, color="FFFFFF")
        dolgu = PatternFill("solid", start_color="1F4E78")
        for hucre in ws[1]:
            hucre.font, hucre.fill = baslik_font, dolgu
            hucre.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        for satir in ws.iter_rows(min_row=2):
            for hucre in satir:
                hucre.font = Font(name="Arial")
                if isinstance(hucre.value, (int, float)):
                    hucre.number_format = "#,##0.00"
        for i, kol in enumerate(kolonlar[:len(ws[1])], 1):
            harf = ws.cell(row=1, column=i).column_letter
            uzunluk = max([len(str(kol))] + [len(str(v)) for v in tum.iloc[:200, i - 1].tolist()])
            ws.column_dimensions[harf].width = min(max(10, uzunluk + 2), 50)
        ws.freeze_panes = "A2"
        ws.auto_filter.ref = ws.dimensions
    log(f"   ✔ {len(tum)} fatura → {hedef_yol}")
    return len(tum)


# --------------------------------------------------------- TARAYICI İŞLERİ ---
class Atlandi(Exception):
    """Kullanıcı firmayı atladı veya işlemi durdurdu."""


class Indirici:
    def __init__(self, log, uyari, cikti_klasoru, dur_olayi, atla_olayi,
                 ilerleme=None, firma_durum=None):
        self.log = log
        self.uyari = uyari
        self.cikti = cikti_klasoru
        self.dur = dur_olayi
        self.atla = atla_olayi
        self.bit_alani_var = None
        self._ilerleme = ilerleme or (lambda adet=1: None)
        self.firma_durum = firma_durum or (lambda idx, durum, bilgi="": None)
        self.firma_adim = 0

    def ilerleme(self, adet=1):
        self.firma_adim += adet
        self._ilerleme(adet)

    def kontrol(self):
        if self.dur.is_set():
            raise Atlandi("işlem durduruldu")
        if self.atla.is_set():
            raise Atlandi("kullanıcı tarafından atlandı")

    def calistir(self, is_listesi, donemler):
        """is_listesi: [(liste_sirasi, mukellef), ...] — sırayla hepsi taranır."""
        beklenen = sum(len(haftalik_parcalar(y, a)) for y, a in donemler)
        sonuclar = []
        with sync_playwright() as p:
            tarayici = p.chromium.launch(headless=False, args=["--start-maximized"])
            try:
                for sira, (idx, m) in enumerate(is_listesi, 1):
                    if self.dur.is_set():
                        break
                    self.atla.clear()
                    self.firma_adim = 0
                    self.firma_durum(idx, "calisiyor", f"{sira}/{len(is_listesi)}")
                    self.log(f"\n=== [{sira}/{len(is_listesi)}] {m['unvan']} ({m['kod']}) ===")
                    sonuc = self.mukellef_isle(tarayici, m, donemler)
                    if self.firma_adim < beklenen:          # atlanan parçaları say
                        self.ilerleme(beklenen - self.firma_adim)
                    sonuc.update(unvan=m["unvan"], kod=m["kod"])
                    sonuclar.append(sonuc)
                    self.firma_durum(idx, sonuc["durum"], sonuc["mesaj"])
            finally:
                tarayici.close()
        self.ozet_yaz(sonuclar, donemler)
        self.log("İşlem durduruldu." if self.dur.is_set() else "Tüm firmalar tamamlandı.")
        return sonuclar

    def mukellef_isle(self, tarayici, m, donemler):
        ctx = tarayici.new_context(accept_downloads=True, locale="tr-TR", no_viewport=True)
        page = ctx.new_page()
        page.set_default_timeout(30000)
        sonuc = {"durum": "tamam", "fatura": 0, "mesaj": ""}
        try:
            self.giris(page, m)
            self.earsiv_sayfasi(page)
            for yil, ay in donemler:
                self.kontrol()
                sonuc["fatura"] += self.donem_isle(page, m, yil, ay)
            sonuc["mesaj"] = f"{sonuc['fatura']} fatura"
            self.cikis(page, m)
        except Atlandi as e:
            sonuc.update(durum="atlandi", mesaj=str(e))
            self.log(f"⏭ {m['unvan']}: {e}")
        except Exception as e:
            sonuc.update(durum="hata", mesaj=str(e).splitlines()[0][:150])
            self.log(f"HATA ({m['unvan']}): {e}")
        finally:
            try:
                ctx.close()
            except Exception:
                pass
        return sonuc

    def ozet_yaz(self, sonuclar, donemler):
        if not sonuclar:
            return
        adlar = {"tamam": "Başarılı", "hata": "Hatalı", "atlandi": "Atlandı"}
        self.log("\n=== ÖZET ===")
        for s in sonuclar:
            self.log(f"{'✔' if s['durum'] == 'tamam' else '!'} {s['unvan']} ({s['kod']}): "
                     f"{adlar[s['durum']]} — {s['mesaj']}")
        try:
            df = pd.DataFrame([{
                "Unvan": s["unvan"], "Kullanıcı Kodu": s["kod"],
                "Durum": adlar[s["durum"]], "Fatura Sayısı": s["fatura"], "Açıklama": s["mesaj"],
            } for s in sonuclar])
            donem_metni = ", ".join(f"{AY_ADLARI[a - 1]} {y}" for y, a in donemler)
            yol = os.path.join(self.cikti, f"Ozet_{time.strftime('%Y%m%d_%H%M')}.xlsx")
            with pd.ExcelWriter(yol, engine="openpyxl") as w:
                df.to_excel(w, index=False, sheet_name="Özet", startrow=2)
                ws = w.sheets["Özet"]
                ws["A1"] = f"e-Arşiv indirme özeti  •  Dönem: {donem_metni}"
                ws["A1"].font = Font(name="Arial", bold=True, size=12)
                for h in ws[3]:
                    h.font = Font(name="Arial", bold=True, color="FFFFFF")
                    h.fill = PatternFill("solid", start_color="1F4E78")
                for satir in ws.iter_rows(min_row=4):
                    for h in satir:
                        h.font = Font(name="Arial")
                for harf, gen in zip("ABCDE", (40, 18, 12, 14, 60)):
                    ws.column_dimensions[harf].width = gen
            self.log(f"Özet dosyası: {yol}")
        except Exception as e:
            self.log(f"! Özet dosyası yazılamadı: {e}")

    # ---- giriş / çıkış
    def giris(self, page, m):
        page.goto(GIB_URL, wait_until="domcontentloaded")
        page.get_by_role("textbox", name="T.C. Kimlik No / Vergi Kimlik").fill(m["kod"])
        page.get_by_role("textbox", name="Şifre").fill(m["sifre"])
        page.get_by_role("textbox", name="Doğrulama Kodu").click()
        page.bring_to_front()
        self.uyari(f">>> {m['unvan']}: Tarayıcıda GÜVENLİK KODUNU yazıp 'Giriş Yap'a basın. "
                   f"(Şifre hatalıysa 'Bu Firmayı Atla' ile sonraki firmaya geçebilirsiniz)")
        arama = page.get_by_role("textbox", name="Hangi işlemi yapmak")
        bitis = time.time() + CAPTCHA_BEKLEME_SN
        while True:
            self.kontrol()
            try:
                if arama.is_visible():
                    break
            except Exception:
                pass
            if time.time() > bitis:
                raise RuntimeError(f"{CAPTCHA_BEKLEME_SN // 60} dakika içinde giriş yapılmadı")
            page.wait_for_timeout(500)
        self.log("Giriş başarılı.")

    def cikis(self, page, m):
        try:
            page.get_by_text(m["kod"]).first.click()
            page.get_by_role("menuitem", name="Çıkış Yap").click()
            page.wait_for_timeout(1500)
            self.log("Çıkış yapıldı.")
        except Exception:
            self.log("Çıkış butonu bulunamadı (oturum tarayıcı kapanınca sonlanır).")

    def earsiv_sayfasi(self, page):
        arama = page.get_by_role("textbox", name="Hangi işlemi yapmak")
        arama.click()
        arama.fill("e ar")
        page.get_by_text("e-Arşiv Faturalarım").first.click()
        page.locator("#basTarih").wait_for(state="visible")
        self.bit_alani_var = page.locator("#bitTarih").count() > 0
        if not self.bit_alani_var:
            self.log("Not: Bitiş tarihi alanı bulunamadı; site bitişi otomatik ayarlıyor, "
                     "dönem dışı faturalar birleştirmede ayıklanacak.")

    # ---- dönem
    def donem_isle(self, page, m, yil, ay):
        etiket = f"{AY_ADLARI[ay - 1]} {yil}"
        parcalar = haftalik_parcalar(yil, ay)
        if not parcalar:
            self.log(f"{etiket}: dönem henüz başlamadı, atlandı.")
            return 0
        self.log(f"{etiket}: {len(parcalar)} parça indirilecek.")

        klasor = os.path.join(self.cikti, temiz_ad(f"{m['unvan']}_{m['kod']}"))
        parca_klasor = os.path.join(klasor, f"{yil}-{ay:02d}_parcalar")
        os.makedirs(parca_klasor, exist_ok=True)

        dosyalar = []
        for i, (bas, bit) in enumerate(parcalar, 1):
            self.kontrol()
            self.log(f"  [{i}/{len(parcalar)}] {bas:%d.%m.%Y} - {bit:%d.%m.%Y}")
            try:
                yol = self.parca_indir(page, bas, bit, parca_klasor, i)
                if yol:
                    dosyalar.append(yol)
            except Exception as e:
                self.log(f"   ! Parça indirilemedi: {e}")
            self.ilerleme()

        hedef = os.path.join(klasor, f"{temiz_ad(m['unvan'])}_{m['kod']}_{yil}-{ay:02d}_eArsiv.xlsx")
        return parcalari_birlestir(dosyalar, yil, ay, hedef, self.log)

    def parca_indir(self, page, bas, bit, klasor, sira):
        self.tarih_sec(page, "basTarih", bas)
        if self.bit_alani_var:
            self.tarih_sec(page, "bitTarih", bit)

        page.get_by_role("button", name="Filtrele").click()
        try:
            page.wait_for_load_state("networkidle", timeout=15000)
        except PWTimeout:
            pass
        page.wait_for_timeout(1500)

        buton = page.get_by_role("button", name=re.compile(r"Excel.e Aktar"))
        try:
            if buton.first.is_disabled():
                self.log("   Kayıt yok.")
                return None
        except Exception:
            pass
        try:
            with page.expect_download(timeout=INDIRME_BEKLEME_SN * 1000) as bilgi:
                buton.first.click()
            indirme = bilgi.value
        except PWTimeout:
            self.log("   İndirme gelmedi (muhtemelen bu aralıkta fatura yok).")
            return None

        uzanti = os.path.splitext(indirme.suggested_filename)[1] or ".xlsx"
        yol = os.path.join(klasor, f"{sira:02d}_{bas:%d.%m}-{bit:%d.%m}{uzanti}")
        indirme.save_as(yol)
        self.log(f"   indirildi: {os.path.basename(yol)}")
        return yol

    # ---- tarih seçimi
    @staticmethod
    def _tarih_dogru(alan, hedef):
        try:
            return re.sub(r"\D", "", alan.input_value()) == hedef.strftime("%d%m%Y")
        except Exception:
            return False

    def tarih_sec(self, page, alan_id, hedef):
        alan = page.locator(f"#{alan_id}")
        if self._tarih_dogru(alan, hedef):
            return
        try:
            self._takvimden_sec(page, alan, alan_id, hedef)
        except Exception:
            pass
        if not self._tarih_dogru(alan, hedef):
            self._klavyeden_yaz(page, alan, hedef)
        if not self._tarih_dogru(alan, hedef):
            raise RuntimeError(f"{alan_id} alanına {hedef:%d.%m.%Y} yazılamadı")

    def _takvimden_sec(self, page, alan, alan_id, hedef):
        kok = alan.locator("xpath=ancestor::div[contains(@class,'MuiInputBase-root')][1]")
        dugme = kok.get_by_role("button", name=re.compile(r"Choose date|Tarih", re.I))
        if dugme.count() == 0:
            sira = 0 if alan_id == "basTarih" else 1
            dugme = page.get_by_role("button", name=re.compile(r"^Choose date")).nth(sira)
        dugme.first.click()

        pencere = page.get_by_role("dialog").last
        try:
            pencere.wait_for(state="visible", timeout=3000)
        except PWTimeout:
            pencere = page

        gecis = pencere.get_by_role("button", name=re.compile(r"calendar view is open, switch"))
        if gecis.count():
            gecis.first.click()
            page.wait_for_timeout(300)
        pencere.get_by_role("button", name=str(hedef.year), exact=True).first.click()
        page.wait_for_timeout(300)
        ay_dugme = pencere.get_by_role("button", name=AY_KISA[hedef.month - 1], exact=True)
        if ay_dugme.count():
            ay_dugme.first.click()
            page.wait_for_timeout(300)
        pencere.get_by_role("gridcell", name=str(hedef.day), exact=True).first.click()
        page.wait_for_timeout(400)
        if pencere is not page and pencere.is_visible():
            page.keyboard.press("Escape")

    @staticmethod
    def _klavyeden_yaz(page, alan, hedef):
        alan.click()
        page.keyboard.press("Control+A")
        page.keyboard.type(hedef.strftime("%d%m%Y"), delay=80)
        page.keyboard.press("Tab")
        page.wait_for_timeout(300)


# ----------------------------------------------------------------- ARAYÜZ ---
RENK = {
    "lacivert": "#0F2A47", "alt_yazi": "#AFC3DB", "vurgu": "#1F6FEB", "vurgu_koyu": "#1757C2",
    "zemin": "#EEF2F7", "kart": "#FFFFFF", "cizgi": "#D9E0E8", "yazi": "#1F2937",
    "soluk": "#6B7280", "yesil": "#15803D", "kirmizi": "#B91C1C", "turuncu": "#B45309",
    "rozet": "#1E8E5A", "alt_bant": "#E3E8EF", "dugme": "#F3F5F8", "dugme_ust": "#E6EBF1",
    "log_zemin": "#0B1220", "log_yazi": "#D1D5DB",
}
YAZI = "Segoe UI"
ILETISIM = "alisarac42@gmail.com"
TANITIM = ("Bu program, SMMM Ali Saraç tarafından meslektaşlarımızın kullanımına ücretsiz "
           "olarak sunulmuştur. Tüm meslektaşlarımıza faydalı olması dileğiyle.")


def dpi_ayarla():
    """Windows'ta yazıların bulanık görünmemesi için."""
    if sys.platform.startswith("win"):
        try:
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            pass


class Uygulama(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("e-Arşiv Fatura İndirici  •  SMMM Ali Saraç")
        try:
            olcek = max(1.0, float(self.tk.call("tk", "scaling")) / 1.333)
        except Exception:
            olcek = 1.0
        self.geometry(f"{int(1080 * olcek)}x{int(780 * olcek)}")
        self.minsize(int(900 * olcek), int(660 * olcek))
        self.configure(bg=RENK["zemin"])
        if sys.platform.startswith("win"):
            try:
                self.state("zoomed")      # tam ekran açılsın
            except tk.TclError:
                pass

        self.q = queue.Queue()
        self.dur_olayi = threading.Event()
        self.atla_olayi = threading.Event()
        self.m_durum = {}
        self.aktif_firma = ""
        self.calisiyor = False
        self.mukellefler = []
        self.donemler = donemleri_listele()
        self.toplam_adim = 0
        self.yapilan_adim = 0

        self._stil_kur()
        self._arayuz_kur()

        varsayilan = os.path.join(uygulama_klasoru(), "mukellefler.xlsx")
        if os.path.exists(varsayilan):
            self.excel_var.set(varsayilan)
            self.mukellef_yukle(sessiz=True)
        self._sayac_guncelle()
        self.protocol("WM_DELETE_WINDOW", self.kapat)
        self.after(200, self._kuyruk_isle)

    # ------------------------------------------------------------ stil
    def _stil_kur(self):
        R = RENK
        s = ttk.Style(self)
        try:
            s.theme_use("clam")
        except tk.TclError:
            pass
        s.configure(".", font=(YAZI, 10), background=R["kart"], foreground=R["yazi"])
        s.configure("TEntry", fieldbackground="white", bordercolor=R["cizgi"],
                    lightcolor=R["cizgi"], darkcolor=R["cizgi"], padding=6)
        s.map("TEntry", bordercolor=[("focus", R["vurgu"])], lightcolor=[("focus", R["vurgu"])])

        def dugme(ad, zemin, yazi, ust, font, pad, pasif_zemin, pasif_yazi, kenar=None):
            kenar = kenar or zemin
            s.configure(ad, font=font, foreground=yazi, background=zemin, bordercolor=kenar,
                        lightcolor=zemin, darkcolor=zemin, focuscolor=zemin, padding=pad,
                        relief="flat")
            s.map(ad,
                  background=[("disabled", pasif_zemin), ("pressed", ust), ("active", ust)],
                  lightcolor=[("disabled", pasif_zemin), ("pressed", ust), ("active", ust)],
                  darkcolor=[("disabled", pasif_zemin), ("pressed", ust), ("active", ust)],
                  foreground=[("disabled", pasif_yazi)])

        dugme("Vurgu.TButton", R["vurgu"], "white", R["vurgu_koyu"], (YAZI, 11, "bold"),
              (24, 10), "#A8C2EE", "#F5F7FA")
        dugme("Dur.TButton", R["dugme"], R["kirmizi"], "#FBE9E9", (YAZI, 11, "bold"),
              (20, 10), R["dugme"], "#B8BEC7", R["cizgi"])
        dugme("Ikincil.TButton", R["dugme"], R["yazi"], R["dugme_ust"], (YAZI, 9),
              (12, 5), R["dugme"], "#A0A7B1", R["cizgi"])

        s.configure("TRadiobutton", background=R["kart"], foreground=R["yazi"], font=(YAZI, 10),
                    indicatorcolor="white", indicatorbackground="white", focuscolor=R["kart"])
        s.map("TRadiobutton", indicatorcolor=[("selected", R["vurgu"])],
              background=[("active", R["kart"])])
        s.configure("Ilerleme.Horizontal.TProgressbar", troughcolor="#E5E9F0",
                    background=R["vurgu"], bordercolor="#E5E9F0", lightcolor=R["vurgu"],
                    darkcolor=R["vurgu"], thickness=8)
        s.configure("Vertical.TScrollbar", background="#E5E9F0", troughcolor="white",
                    bordercolor="white", arrowcolor=R["soluk"], gripcount=0,
                    lightcolor="#E5E9F0", darkcolor="#E5E9F0")

    # ------------------------------------------------------ yardımcılar
    def _kart(self, ust, no, baslik):
        R = RENK
        dis = tk.Frame(ust, bg=R["kart"], highlightthickness=1, highlightbackground=R["cizgi"])
        bas = tk.Frame(dis, bg=R["kart"])
        bas.pack(fill="x", padx=16, pady=(12, 8))
        if no:
            tk.Label(bas, text=no, bg=R["vurgu"], fg="white", font=(YAZI, 9, "bold"),
                     width=2).pack(side="left")
        tk.Label(bas, text=baslik, bg=R["kart"], fg=R["yazi"],
                 font=(YAZI, 11, "bold")).pack(side="left", padx=(8 if no else 0, 0))
        ic = tk.Frame(dis, bg=R["kart"])
        ic.pack(fill="both", expand=True, padx=16, pady=(0, 14))
        return dis, bas, ic

    def _liste(self, ust):
        R = RENK
        cerceve = tk.Frame(ust, bg=R["cizgi"])
        cerceve.pack(fill="both", expand=True)
        lb = tk.Listbox(cerceve, selectmode="extended", exportselection=False, bg="white",
                        fg=R["yazi"], selectbackground=R["vurgu"], selectforeground="white",
                        relief="flat", borderwidth=0, highlightthickness=0, activestyle="none",
                        font=(YAZI, 10), height=8)
        sb = ttk.Scrollbar(cerceve, orient="vertical", command=lb.yview)
        lb.configure(yscrollcommand=sb.set)
        lb.pack(side="left", fill="both", expand=True, padx=(1, 0), pady=1)
        sb.pack(side="right", fill="y", padx=(0, 1), pady=1)
        lb.bind("<<ListboxSelect>>", lambda e: self._sayac_guncelle())
        return lb

    def _durum(self, metin, renk="soluk"):
        self.lbl_durum.config(text=metin, fg=RENK[renk])

    # ------------------------------------------------------------ arayüz
    def _arayuz_kur(self):
        R = RENK

        # --- üst bant
        ust = tk.Frame(self, bg=R["lacivert"])
        ust.pack(fill="x")
        sol = tk.Frame(ust, bg=R["lacivert"])
        sol.pack(side="left", padx=24, pady=14)
        tk.Label(sol, text="e-Arşiv Fatura İndirici", bg=R["lacivert"], fg="white",
                 font=(YAZI, 17, "bold")).pack(anchor="w")
        tk.Label(sol, text="GİB Dijital Vergi Dairesi  •  7 günlük parçalarla indirme, "
                           "tek Excel'de birleştirme",
                 bg=R["lacivert"], fg=R["alt_yazi"], font=(YAZI, 9)).pack(anchor="w", pady=(2, 0))
        tk.Label(ust, text="MESLEKTAŞLARIMIZA ÜCRETSİZ", bg=R["rozet"], fg="white",
                 font=(YAZI, 8, "bold"), padx=10, pady=4).pack(side="right", padx=24)
        tk.Frame(self, bg=R["vurgu"], height=3).pack(fill="x")

        # --- alt bilgi bandı
        alt = tk.Frame(self, bg=R["alt_bant"])
        alt.pack(side="bottom", fill="x")
        eposta = tk.Label(alt, text=f"✉  {ILETISIM}", bg=R["alt_bant"], fg=R["vurgu"],
                          font=(YAZI, 8, "underline"), cursor="hand2")
        eposta.pack(side="right", padx=18, pady=7)
        eposta.bind("<Button-1>", lambda e: webbrowser.open(f"mailto:{ILETISIM}"))
        tanitim = tk.Label(alt, text=TANITIM, bg=R["alt_bant"], fg=R["soluk"],
                           font=(YAZI, 8), anchor="w", justify="left")
        tanitim.pack(side="left", fill="x", expand=True, padx=18, pady=7)
        alt.bind("<Configure>", lambda e: tanitim.config(wraplength=max(300, e.width - 260)))

        # --- gövde
        govde = tk.Frame(self, bg=R["zemin"])
        govde.pack(fill="both", expand=True, padx=18, pady=16)
        govde.columnconfigure(0, weight=3)
        govde.columnconfigure(1, weight=2)
        govde.rowconfigure(0, weight=3)
        govde.rowconfigure(3, weight=2)

        # 1) Mükellefler
        k1, b1, i1 = self._kart(govde, "1", "Mükellefler")
        k1.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        self.lbl_m_say = tk.Label(b1, bg=R["kart"], fg=R["soluk"], font=(YAZI, 9))
        self.lbl_m_say.pack(side="right")
        satir = tk.Frame(i1, bg=R["kart"])
        satir.pack(fill="x", pady=(0, 8))
        self.excel_var = tk.StringVar()
        ttk.Entry(satir, textvariable=self.excel_var).pack(side="left", fill="x", expand=True)
        ttk.Button(satir, text="Gözat", style="Ikincil.TButton",
                   command=self.excel_sec).pack(side="left", padx=(6, 0))
        ttk.Button(satir, text="Yenile", style="Ikincil.TButton",
                   command=self.mukellef_yukle).pack(side="left", padx=(6, 0))
        mod = tk.Frame(i1, bg=R["kart"])
        mod.pack(fill="x", pady=(0, 8))
        self.mod_var = tk.StringVar(value="tumu")
        ttk.Radiobutton(mod, text="Tüm firmaları sırayla tara", value="tumu",
                        variable=self.mod_var, command=self._mod_degisti).pack(side="left")
        ttk.Radiobutton(mod, text="Sadece seçtiklerimi tara", value="secili",
                        variable=self.mod_var, command=self._mod_degisti).pack(side="left", padx=(18, 0))
        satir = tk.Frame(i1, bg=R["kart"])
        satir.pack(side="bottom", fill="x", pady=(8, 0))
        ttk.Button(satir, text="Tümünü Seç", style="Ikincil.TButton",
                   command=lambda: self._hepsini_sec(self.lb_m)).pack(side="left")
        ttk.Button(satir, text="Seçimi Temizle", style="Ikincil.TButton",
                   command=lambda: self._temizle(self.lb_m)).pack(side="left", padx=6)
        ttk.Button(satir, text="Listeyi Excel'de Aç", style="Ikincil.TButton",
                   command=self.excel_ac).pack(side="right")
        self.lb_m = self._liste(i1)

        # 2) Dönem
        k2, b2, i2 = self._kart(govde, "2", "Dönem")
        k2.grid(row=0, column=1, sticky="nsew", padx=(8, 0))
        self.lbl_d_say = tk.Label(b2, bg=R["kart"], fg=R["soluk"], font=(YAZI, 9))
        self.lbl_d_say.pack(side="right")
        satir = tk.Frame(i2, bg=R["kart"])
        satir.pack(side="bottom", fill="x", pady=(8, 0))
        ttk.Button(satir, text="Geçen Ay", style="Ikincil.TButton",
                   command=self._gecen_ay).pack(side="left")
        ttk.Button(satir, text="Tümü", style="Ikincil.TButton",
                   command=lambda: self._hepsini_sec(self.lb_d)).pack(side="left", padx=(6, 0))
        ttk.Button(satir, text="Temizle", style="Ikincil.TButton",
                   command=lambda: self._temizle(self.lb_d)).pack(side="left", padx=(6, 0))
        tk.Label(i2, text="Liste bilgisayar tarihine göre her ay kendiliğinden güncellenir "
                          "(son 3 ay).", bg=R["kart"], fg=R["soluk"], font=(YAZI, 8),
                 anchor="w", justify="left", wraplength=320).pack(side="bottom", fill="x", pady=(6, 0))
        self.lb_d = self._liste(i2)
        for y, a in self.donemler:
            self.lb_d.insert("end", f"  {AY_ADLARI[a - 1]} {y}")
        self._gecen_ay()

        # 3) Çıktı klasörü
        k3, _, i3 = self._kart(govde, "3", "Çıktı Klasörü")
        k3.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(14, 0))
        self.cikti_var = tk.StringVar(value=os.path.join(uygulama_klasoru(), "e-Arsiv_Ciktilar"))
        ttk.Entry(i3, textvariable=self.cikti_var).pack(side="left", fill="x", expand=True)
        ttk.Button(i3, text="Gözat", style="Ikincil.TButton",
                   command=self.klasor_sec).pack(side="left", padx=(6, 0))
        ttk.Button(i3, text="Klasörü Aç", style="Ikincil.TButton",
                   command=self.klasor_ac).pack(side="left", padx=(6, 0))

        # İşlem çubuğu
        k4 = tk.Frame(govde, bg=R["kart"], highlightthickness=1, highlightbackground=R["cizgi"])
        k4.grid(row=2, column=0, columnspan=2, sticky="ew", pady=14)
        i4 = tk.Frame(k4, bg=R["kart"])
        i4.pack(fill="x", padx=16, pady=14)
        self.btn_basla = ttk.Button(i4, text="▶   İndirmeyi Başlat", style="Vurgu.TButton",
                                    command=self.baslat)
        self.btn_basla.pack(side="left")
        self.btn_dur = ttk.Button(i4, text="■   Durdur", style="Dur.TButton",
                                  command=self.durdur, state="disabled")
        self.btn_dur.pack(side="left", padx=(8, 0))
        self.btn_atla = ttk.Button(i4, text="⏭   Bu Firmayı Atla", style="Dur.TButton",
                                   command=self.atla, state="disabled")
        self.btn_atla.pack(side="left", padx=(8, 0))
        sag = tk.Frame(i4, bg=R["kart"])
        sag.pack(side="left", fill="x", expand=True, padx=(22, 0))
        ust_satir = tk.Frame(sag, bg=R["kart"])
        ust_satir.pack(fill="x")
        self.lbl_durum = tk.Label(ust_satir, text="Hazır", bg=R["kart"], fg=R["soluk"],
                                  font=(YAZI, 10, "bold"), anchor="w")
        self.lbl_durum.pack(side="left")
        self.lbl_yuzde = tk.Label(ust_satir, text="", bg=R["kart"], fg=R["soluk"], font=(YAZI, 9))
        self.lbl_yuzde.pack(side="right")
        self.cubuk = ttk.Progressbar(sag, style="Ilerleme.Horizontal.TProgressbar",
                                     mode="determinate", maximum=100)
        self.cubuk.pack(fill="x", pady=(8, 0))

        # İşlem günlüğü
        k5, b5, i5 = self._kart(govde, None, "İşlem Günlüğü")
        k5.grid(row=3, column=0, columnspan=2, sticky="nsew")
        ttk.Button(b5, text="Temizle", style="Ikincil.TButton",
                   command=self.log_temizle).pack(side="right")
        cerceve = tk.Frame(i5, bg=R["log_zemin"])
        cerceve.pack(fill="both", expand=True)
        self.log_kutu = tk.Text(cerceve, height=8, state="disabled", bg=R["log_zemin"],
                                fg=R["log_yazi"], relief="flat", borderwidth=0,
                                highlightthickness=0, font=("Consolas", 9), padx=12, pady=10,
                                wrap="word")
        sb = ttk.Scrollbar(cerceve, orient="vertical", command=self.log_kutu.yview)
        self.log_kutu.configure(yscrollcommand=sb.set)
        self.log_kutu.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        self.log_kutu.tag_configure("zaman", foreground="#6B7280")
        self.log_kutu.tag_configure("basari", foreground="#4ADE80")
        self.log_kutu.tag_configure("hata", foreground="#F87171")
        self.log_kutu.tag_configure("uyari", foreground="#FBBF24", font=("Consolas", 9, "bold"))
        self.log_kutu.tag_configure("baslik", foreground="#60A5FA", font=("Consolas", 9, "bold"))

    # ------------------------------------------------------ seçim işleri
    def _hepsini_sec(self, lb):
        lb.select_set(0, "end")
        self._sayac_guncelle()

    def _temizle(self, lb):
        lb.selection_clear(0, "end")
        self._sayac_guncelle()

    def _gecen_ay(self):
        self.lb_d.selection_clear(0, "end")
        bugun = date.today()
        gecen = (bugun.year, bugun.month - 1) if bugun.month > 1 else (bugun.year - 1, 12)
        i = self.donemler.index(gecen) if gecen in self.donemler else 0
        self.lb_d.select_set(i)
        self.lb_d.see(0)
        self._sayac_guncelle()

    def _mod_degisti(self):
        if self.mod_var.get() == "tumu":
            self.lb_m.selection_clear(0, "end")
        self._sayac_guncelle()

    def _sayac_guncelle(self):
        if not hasattr(self, "lbl_m_say"):
            return
        secili = len(self.lb_m.curselection())
        # Tümü modundayken kullanıcı listeden seçim değiştirirse "seçtiklerim" moduna geç
        if self.mod_var.get() == "tumu" and secili:
            self.mod_var.set("secili")
        if self.mod_var.get() == "tumu":
            metin = f"{len(self.mukellefler)} firmanın tümü taranacak"
        else:
            metin = f"{len(self.mukellefler)} kayıt  •  {secili} seçili"
        self.lbl_m_say.config(text=metin)
        self.lbl_d_say.config(text=f"{len(self.lb_d.curselection())} seçili")

    FIRMA_DURUM = {
        "sirada":    ("⏳", "#6B7280", "white"),
        "calisiyor": ("▶", "#1757C2", "#FFF4D6"),
        "tamam":     ("✔", "#15803D", "white"),
        "hata":      ("✖", "#B91C1C", "white"),
        "atlandi":   ("⏭", "#B45309", "white"),
    }

    def _m_metin(self, i):
        m = self.mukellefler[i]
        durum, bilgi = self.m_durum.get(i, (None, ""))
        simge = self.FIRMA_DURUM[durum][0] + " " if durum else ""
        ek = f"   —  {bilgi}" if bilgi and durum in ("tamam", "hata", "atlandi") else ""
        return f"  {simge}{m['unvan']}   ({m['kod']}){ek}"

    def _firma_isaretle(self, i, durum, bilgi=""):
        if i >= self.lb_m.size():
            return
        self.m_durum[i] = (durum, bilgi)
        secili = self.lb_m.selection_includes(i)
        self.lb_m.delete(i)
        self.lb_m.insert(i, self._m_metin(i))
        _, renk, zemin = self.FIRMA_DURUM[durum]
        self.lb_m.itemconfig(i, fg=renk, bg=zemin)
        if secili:
            self.lb_m.select_set(i)
        if durum == "calisiyor":
            self.lb_m.see(i)
            self.aktif_firma = f"Firma {bilgi}  •  {self.mukellefler[i]['unvan']}"

    # ----------------------------------------------------------- olaylar
    def excel_sec(self):
        yol = filedialog.askopenfilename(filetypes=[("Excel", "*.xlsx *.xls")])
        if yol:
            self.excel_var.set(yol)
            self.mukellef_yukle()

    def _ac(self, yol):
        if sys.platform.startswith("win"):
            os.startfile(yol)
        else:
            import subprocess
            subprocess.Popen(["open" if sys.platform == "darwin" else "xdg-open", yol])

    def excel_ac(self):
        yol = self.excel_var.get()
        if os.path.exists(yol):
            self._ac(yol)
        else:
            messagebox.showwarning("Uyarı", "Mükellef listesi dosyası bulunamadı.")

    def klasor_sec(self):
        yol = filedialog.askdirectory()
        if yol:
            self.cikti_var.set(yol)

    def klasor_ac(self):
        yol = self.cikti_var.get()
        os.makedirs(yol, exist_ok=True)
        self._ac(yol)

    def mukellef_yukle(self, sessiz=False):
        try:
            self.mukellefler = mukellefleri_oku(self.excel_var.get())
        except Exception as e:
            if not sessiz:
                messagebox.showerror("Hata", f"Mükellef listesi okunamadı:\n{e}")
            return
        self.m_durum = {}
        self.lb_m.delete(0, "end")
        for i in range(len(self.mukellefler)):
            self.lb_m.insert("end", self._m_metin(i))
        self._sayac_guncelle()
        self.log(f"{len(self.mukellefler)} mükellef yüklendi.")

    def baslat(self):
        if not self.mukellefler:
            messagebox.showwarning("Uyarı", "Mükellef listesi boş. Önce Excel listesini yükleyin.")
            return
        if self.mod_var.get() == "tumu":
            siralar = list(range(len(self.mukellefler)))
        else:
            siralar = list(self.lb_m.curselection())
        secili_m = [(i, self.mukellefler[i]) for i in siralar]
        secili_d = sorted(self.donemler[i] for i in self.lb_d.curselection())
        if not secili_m:
            messagebox.showwarning("Uyarı", "Lütfen en az bir firma seçin "
                                            "ya da 'Tüm firmaları sırayla tara'yı işaretleyin.")
            return
        if not secili_d:
            messagebox.showwarning("Uyarı", "Lütfen en az bir dönem seçin.")
            return
        cikti = self.cikti_var.get().strip()
        try:
            os.makedirs(cikti, exist_ok=True)
        except Exception as e:
            messagebox.showerror("Hata", f"Çıktı klasörü oluşturulamadı:\n{e}")
            return

        self.toplam_adim = max(1, len(secili_m) *
                               sum(len(haftalik_parcalar(y, a)) for y, a in secili_d))
        self.yapilan_adim = 0
        self.cubuk["value"] = 0
        self.lbl_yuzde.config(text="%0")
        self._durum("Tarayıcı açılıyor…", "vurgu")

        # liste işaretlerini sıfırla, sıradakileri işaretle
        for i in range(len(self.mukellefler)):
            self.m_durum.pop(i, None)
            self.lb_m.delete(i)
            self.lb_m.insert(i, self._m_metin(i))
        # renkli durum işaretleri görünsün diye seçim vurgusu kaldırılır, sonra geri gelir
        self.son_secim = siralar if self.mod_var.get() == "secili" else []
        self.lb_m.selection_clear(0, "end")
        for i in siralar:
            self._firma_isaretle(i, "sirada")
        self.aktif_firma = ""

        self.dur_olayi.clear()
        self.atla_olayi.clear()
        self.calisiyor = True
        self.btn_basla.config(state="disabled")
        self.btn_dur.config(state="normal")
        self.btn_atla.config(state="normal")
        threading.Thread(target=self._calis, args=(secili_m, secili_d, cikti), daemon=True).start()

    def _calis(self, mukellefler, donemler, cikti):
        try:
            sonuclar = Indirici(
                self.log, self.uyari, cikti, self.dur_olayi, self.atla_olayi,
                ilerleme=lambda adet=1: self.q.put(("ilerle", adet)),
                firma_durum=lambda i, d, b="": self.q.put(("firma", (i, d, b))),
            ).calistir(mukellefler, donemler)
            self.q.put(("ozet", sonuclar))
        except Exception as e:
            self.log(f"Genel hata: {e}")
            self.log(traceback.format_exc(limit=3))
        finally:
            self.q.put(("bitti", None))

    def atla(self):
        self.atla_olayi.set()
        self._durum("Firma atlanıyor…", "turuncu")
        self.log("Bu firma atlanıyor, sıradaki firmaya geçilecek.")

    def durdur(self):
        self.dur_olayi.set()
        self._durum("Durduruluyor…", "turuncu")
        self.log("Durdurma istendi; mevcut adım bitince durulacak.")

    def kapat(self):
        if self.calisiyor and not messagebox.askyesno(
                "Çıkış", "İndirme devam ediyor. Yine de kapatılsın mı?"):
            return
        self.dur_olayi.set()
        self.destroy()

    # ------------------------------------------------------------- günlük
    def log(self, mesaj):
        self.q.put(("log", mesaj))

    def uyari(self, mesaj):
        self.q.put(("uyari", mesaj))

    def log_temizle(self):
        self.log_kutu.config(state="normal")
        self.log_kutu.delete("1.0", "end")
        self.log_kutu.config(state="disabled")

    @staticmethod
    def _etiket(satir, tur):
        s = satir.strip()
        if tur == "uyari":
            return ("uyari",)
        if "HATA" in s or "hata:" in s.lower() or s.startswith("!"):
            return ("hata",)
        if s.startswith("==="):
            return ("baslik",)
        if s.startswith("✔") or "başarılı" in s or s.startswith("indirildi") or "tamamlandı" in s:
            return ("basari",)
        return ()

    def _log_yaz(self, mesaj, tur):
        self.log_kutu.config(state="normal")
        for satir in str(mesaj).split("\n"):
            if not satir.strip():
                continue
            self.log_kutu.insert("end", time.strftime("%H:%M:%S  "), "zaman")
            self.log_kutu.insert("end", satir + "\n", self._etiket(satir, tur))
        self.log_kutu.see("end")
        self.log_kutu.config(state="disabled")

    def _ozet_goster(self, sonuclar):
        if not sonuclar:
            return
        say = {d: sum(1 for s in sonuclar if s["durum"] == d) for d in ("tamam", "hata", "atlandi")}
        fatura = sum(s["fatura"] for s in sonuclar)
        metin = (f"Taranan firma: {len(sonuclar)}\n\n"
                 f"✔ Başarılı: {say['tamam']}\n✖ Hatalı: {say['hata']}\n⏭ Atlanan: {say['atlandi']}\n\n"
                 f"Toplam fatura: {fatura}\n\nAyrıntılar çıktı klasöründeki Özet dosyasında.")
        (messagebox.showwarning if say["hata"] else messagebox.showinfo)("İşlem Özeti", metin)

    def _kuyruk_isle(self):
        try:
            while True:
                tur, veri = self.q.get_nowait()
                if tur in ("log", "uyari"):
                    self._log_yaz(veri, tur)
                    if tur == "uyari":
                        self._durum("Güvenlik kodunu tarayıcıda girip 'Giriş Yap'a basın", "turuncu")
                        self.bell()
                    elif str(veri).startswith("Giriş başarılı"):
                        self._durum(f"{self.aktif_firma}  —  indiriliyor…", "vurgu")
                elif tur == "firma":
                    self._firma_isaretle(*veri)
                    if veri[1] == "calisiyor":
                        self._durum(f"{self.aktif_firma}  —  giriş bekleniyor", "vurgu")
                elif tur == "ilerle":
                    self.yapilan_adim += veri or 1
                    oran = min(100, self.yapilan_adim * 100 / self.toplam_adim)
                    self.cubuk["value"] = oran
                    self.lbl_yuzde.config(text=f"%{oran:.0f}")
                    if self.aktif_firma:
                        self._durum(f"{self.aktif_firma}  —  indiriliyor…", "vurgu")
                elif tur == "ozet":
                    self._ozet_goster(veri)
                elif tur == "bitti":
                    self.calisiyor = False
                    self.btn_basla.config(state="normal")
                    self.btn_dur.config(state="disabled")
                    self.btn_atla.config(state="disabled")
                    for i in getattr(self, "son_secim", []):
                        self.lb_m.select_set(i)
                    if self.dur_olayi.is_set():
                        self._durum("Durduruldu", "turuncu")
                    else:
                        self.cubuk["value"] = 100
                        self.lbl_yuzde.config(text="%100")
                        self._durum("Tamamlandı  ✔", "yesil")
        except queue.Empty:
            pass
        self.after(200, self._kuyruk_isle)


if __name__ == "__main__":
    dpi_ayarla()
    Uygulama().mainloop()
